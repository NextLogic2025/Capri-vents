import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import colors from '../../theme/colors';

const ScreenHeader = ({ title, subtitle, icon, onIconPress, rounded = true, style }) => {
  const { top } = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.container,
        rounded ? null : styles.flat,
        { paddingTop: top + 8 },
        style,
      ]}
    >
      <View>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      {icon ? (
        <TouchableOpacity onPress={onIconPress} style={styles.iconButton} activeOpacity={0.8}>
          <Ionicons name={icon} size={20} color={colors.white} />
        </TouchableOpacity>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.primary,
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
    paddingHorizontal: 20,
    paddingBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  flat: {
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },
  title: {
    color: colors.white,
    fontSize: 24,
    fontWeight: '800',
  },
  subtitle: {
    color: colors.white,
    opacity: 0.9,
    marginTop: 4,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default ScreenHeader;
