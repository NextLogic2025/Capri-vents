import React, { useMemo, useState } from 'react';
import {
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import colors from '../../theme/colors';
import globalStyles from '../../theme/styles';
import { useAppContext } from '../../context/AppContext';
import SectionCard from '../../Cliente/components/SectionCard';
import PrimaryButton from '../../Cliente/components/PrimaryButton';
import EmptyState from '../../Cliente/components/EmptyState';
import VendedorCobroCard from '../components/VendedorCobroCard';

const formatCurrency = (value = 0) => {
  const amount = Number(value) || 0;
  return amount.toFixed(2);
};

const isOverdue = (item) => {
  const status = (item.estado || item.status || '').toUpperCase();
  if (status === 'VENCIDA' || status === 'VENCIDO') return true;
  const due = new Date(item.fechaVencimiento || item.dueDate);
  if (Number.isNaN(due.getTime())) return false;
  const today = new Date();
  return due < today;
};

const normalizeStatus = (status = '') => {
  const key = status.toUpperCase();
  if (key.includes('PAGAD')) return 'PAGADA';
  if (key.includes('VENC')) return 'VENCIDA';
  if (key.includes('PEND')) return 'PENDIENTE';
  return key || 'PENDIENTE';
};

const VendedorCobrosScreen = () => {
  const { vendorAssignedOrders = [], vendorAssignedCredits = [] } = useAppContext();
  const [selectedCobro, setSelectedCobro] = useState(null);
  const [detailVisible, setDetailVisible] = useState(false);
  const [cashModalVisible, setCashModalVisible] = useState(false);
  const [cashAmount, setCashAmount] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');

  const cobros = useMemo(() => {
    const pendingOrders = vendorAssignedOrders
      .filter((order) => {
        const method = (order.paymentMethod || '').toUpperCase();
        const paymentStatus = (order.paymentStatus || '').toUpperCase();
        return method === 'EFECTIVO' && !paymentStatus.includes('PAGAD');
      })
      .map((order) => ({
        id: `PED-${order.id}`,
        tipo: 'PEDIDO',
        code: order.code,
        clienteNombre: order.clientName,
        monto: order.total,
        fechaVencimiento: order.deliveryDate || order.date,
        estado: normalizeStatus(order.paymentStatus),
        paymentMethod: order.paymentMethod,
        reference: order.id,
      }));

    const pendingInstallments = vendorAssignedCredits.flatMap((credit) => {
      return (credit.installments || []).map((installment) => {
        const status = normalizeStatus(installment.status);
        if (status === 'PAGADA') return null;
        return {
          id: `${credit.id}-${installment.id}`,
          tipo: 'CUOTA',
          code: credit.orderCode,
          clienteNombre: credit.clientName,
          monto: installment.amount,
          fechaVencimiento: installment.dueDate,
          estado: status,
          numero: installment.number,
          paymentMethod: installment.paymentMethod || 'EFECTIVO',
          reference: credit.id,
        };
      });
    }).filter(Boolean);

    return [...pendingOrders, ...pendingInstallments];
  }, [vendorAssignedOrders, vendorAssignedCredits]);

  const prioridad = cobros.filter(isOverdue);
  const proximos = cobros.filter((item) => !isOverdue(item));

  const openDetail = (item) => {
    setSelectedCobro(item);
    setDetailVisible(true);
    setCashAmount(formatCurrency(item.monto ?? item.amount));
    setInvoiceNumber('');
  };

  const closeDetail = () => {
    setDetailVisible(false);
    setSelectedCobro(null);
  };

  const openCashModal = () => setCashModalVisible(true);
  const closeCashModal = () => setCashModalVisible(false);

  const handleViewReceipt = () => {
    // BACKEND: descargar o abrir comprobante asociado
    Alert.alert('Comprobante', 'Se mostraria el comprobante registrado para este cobro.');
  };

  const handleUploadInvoice = () => {
    // BACKEND: subir archivo/foto del comprobante en efectivo
    Alert.alert('Factura', 'Simulacion de cargar factura fisica.');
  };

  const handleConfirmCash = () => {
    if (!selectedCobro) return;
    // BACKEND: registrar pago manual del cobro / cuota
    console.log('Registrar pago efectivo', {
      cobroId: selectedCobro.id,
      amount: cashAmount,
      invoiceNumber,
    });
    Alert.alert('Pago registrado', 'Pago en efectivo registrado correctamente.');
    setCashModalVisible(false);
    setDetailVisible(false);
    setSelectedCobro(null);
  };

  const renderCobroDetail = () => {
    if (!selectedCobro) return null;
    const isTransfer = (selectedCobro.paymentMethod || '').toUpperCase().includes('TRANS');
    const isPaid = (selectedCobro.estado || '').toUpperCase() === 'PAGADA';
    return (
      <Modal
        visible={detailVisible}
        animationType="slide"
        transparent
        onRequestClose={closeDetail}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{selectedCobro.tipo}</Text>
              <TouchableOpacity onPress={closeDetail} style={styles.closeButton}>
                <Text style={styles.closeButtonText}>x</Text>
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              <SectionCard title="Detalle">
                <Text style={styles.detailLabel}>Cliente</Text>
                <Text style={styles.detailValue}>{selectedCobro.clienteNombre}</Text>
                <Text style={styles.detailLabel}>Referencia</Text>
                <Text style={styles.detailValue}>{selectedCobro.code || selectedCobro.reference}</Text>
                <Text style={styles.detailLabel}>Monto</Text>
                <Text style={styles.totalValue}>${formatCurrency(selectedCobro.monto)}</Text>
                <Text style={styles.detailLabel}>Fecha de vencimiento</Text>
                <Text style={styles.detailValue}>
                  {selectedCobro.fechaVencimiento || 'Sin fecha'}
                </Text>
                <Text style={styles.detailLabel}>Estado</Text>
                <Text style={styles.detailValue}>{selectedCobro.estado}</Text>
              </SectionCard>
              <SectionCard title="Acciones">
                {isTransfer && (
                  <PrimaryButton
                    title="Ver comprobante"
                    style={{ marginBottom: 12 }}
                    onPress={handleViewReceipt}
                  />
                )}
                {!isPaid && (
                  <PrimaryButton title="Registrar pago en efectivo" onPress={openCashModal} />
                )}
              </SectionCard>
            </ScrollView>
          </View>
        </View>
      </Modal>
    );
  };

  const renderCashModal = () => {
    if (!selectedCobro) return null;
    return (
      <Modal
        visible={cashModalVisible}
        animationType="fade"
        transparent
        onRequestClose={closeCashModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.cashModalCard}>
            <Text style={styles.modalTitle}>Registrar pago</Text>
            <Text style={styles.detailLabel}>Monto</Text>
            <TextInput
              style={styles.input}
              keyboardType="decimal-pad"
              value={cashAmount}
              onChangeText={setCashAmount}
            />
            <Text style={styles.detailLabel}>Numero de factura</Text>
            <TextInput
              style={styles.input}
              placeholder="Ej. F001-123"
              value={invoiceNumber}
              onChangeText={setInvoiceNumber}
            />
            <TouchableOpacity style={styles.secondaryButton} onPress={handleUploadInvoice}>
              <Text style={styles.secondaryButtonText}>Subir foto de factura</Text>
            </TouchableOpacity>
            <PrimaryButton title="Confirmar" onPress={handleConfirmCash} style={{ marginTop: 12 }} />
            <TouchableOpacity onPress={closeCashModal} style={styles.modalCancel}>
              <Text style={styles.modalCancelText}>Cancelar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };

  const renderCobrosSection = (title, data, emptyMessage) => (
    <SectionCard title={title}>
      {data.length === 0 ? (
        <EmptyState title={emptyMessage} subtitle="" iconName="checkmark-circle-outline" />
      ) : (
        data.map((item) => (
          <VendedorCobroCard key={item.id} item={item} onPress={() => openDetail(item)} />
        ))
      )}
    </SectionCard>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.contentContainer} showsVerticalScrollIndicator={false}>
        <Text style={styles.screenTitle}>Cobros & Creditos</Text>
        <Text style={styles.screenSubtitle}>
          Gestiona cobros pendientes de pedidos al contado y cuotas de credito.
        </Text>
        {renderCobrosSection('Prioridad (Vencidos)', prioridad, 'Sin cobros vencidos')}
        {renderCobrosSection('Proximos a vencer', proximos, 'Sin cobros pendientes')}
      </ScrollView>
      {renderCobroDetail()}
      {renderCashModal()}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 140,
  },
  screenTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.textDark,
  },
  screenSubtitle: {
    marginTop: 4,
    color: colors.textLight,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  modalCard: {
    width: '100%',
    maxHeight: '90%',
    backgroundColor: colors.white,
    borderRadius: 26,
    padding: 18,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.textDark,
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 14,
    backgroundColor: colors.borderSoft,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeButtonText: {
    fontSize: 20,
    color: colors.textDark,
    fontWeight: '700',
  },
  detailLabel: {
    fontSize: 12,
    color: colors.textLight,
    marginTop: 10,
  },
  detailValue: {
    fontSize: 14,
    color: colors.textDark,
    fontWeight: '600',
    marginTop: 2,
  },
  totalValue: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.primary,
    marginTop: 4,
  },
  cashModalCard: {
    width: '100%',
    backgroundColor: colors.white,
    borderRadius: 22,
    padding: 20,
  },
  input: {
    ...globalStyles.input,
    marginTop: 6,
  },
  secondaryButton: {
    ...globalStyles.secondaryButton,
    marginTop: 14,
  },
  secondaryButtonText: {
    ...globalStyles.secondaryButtonText,
  },
  modalCancel: {
    marginTop: 10,
    alignItems: 'center',
  },
  modalCancelText: {
    color: colors.textLight,
    fontWeight: '600',
  },
});

export default VendedorCobrosScreen;
